// Fill out your copyright notice in the Description page of Project Settings.


#include "PawnEnemy.h"

APawnEnemy::APawnEnemy() 
{

}

void APawnEnemy::Attack() 
{

 }